<?php 
	function eliminarFila($id_eliminar, $obj){
        $resultado = $obj->eliminar($id_eliminar);

        return $respuesta = array(
            'respuesta' => 'eliminado',
            'id' => $id_eliminar
        );
    }
    function consultarFilas($id, $obj, $id_modulo, $modulo){
        if ( empty($id) ) {

            $resultado = $obj->consulta();

            while ( $fila = $resultado->fetch_assoc() ){
                $id_modulo_array[] = $fila[$id_modulo];
                $arreglo[] = $fila;
            }
        }else{

            $resultado = $obj->consultar_id($id);

            while ( $fila = $resultado->fetch_assoc() ){
                $id_modulo_array[] = $fila[$id_modulo];
                $arreglo[] = $fila;
            }
        }

        $respuesta = array(
            'respuesta' => '',
            'id' => $id_modulo_array,
            'fila' => $arreglo,
            'modulo' => $modulo,
        );

        if ( !empty($id) ) {

            $reemplazo = array('respuesta' => "consulta_id");

            return $respuesta = array_replace($respuesta, $reemplazo);
        }else{
            $reemplazo = array('respuesta' => "mostrar_datos");

            return $respuesta = array_replace($respuesta, $reemplazo);
        }
    }
?>
				