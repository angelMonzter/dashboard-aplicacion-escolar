
				<?php 
				require("mysql/conexion.php");
				class Administrador extends DBA{
					public function alta($id_admin,$nombre,$apellido,$correo,$contrasena,$privilegios) {
						$this->sentencia = "INSERT INTO administrador VALUES ($id_admin,'$nombre','$apellido','$correo','$contrasena','$privilegios');";
						$this->ejecutar_sentencia();
					}
					public function consulta() {
						$this->sentencia = "SELECT * FROM administrador;";
						return $this->obtener_sentencia();
					}
					public function modificar($id_admin,$nombre,$apellido,$correo,$contrasena,$privilegios){
						$this->sentencia="UPDATE $id_admin,'$nombre','$apellido','$correo','$contrasena','$privilegios' FROM administrador;";
						$this->ejecutar_sentencia();
					}
					public function eliminar(){
						$this->sentencia="DELETE $id_admin,'$nombre','$apellido','$correo','$contrasena','$privilegios' FROM administrador;";
						$this->ejecutar_sentencia();
					}
				}
				?>
				