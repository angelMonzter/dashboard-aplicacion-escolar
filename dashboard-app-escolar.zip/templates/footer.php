<footer class="footer py-4  ">
  <div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
      <div class="col-lg-6 mb-lg-0 mb-4">
        <div class="copyright text-center text-sm text-lg-start">
          © 
          <script>
            document.write(new Date().getFullYear())
          </script>,
          Hecho con <i class="fa fa-heart" aria-hidden="true"></i>
        </div>
      </div>
      <div class="col-lg-6">
        <ul class="nav nav-footer justify-content-center justify-content-lg-end">
          <li class="nav-item">
            <a href="https://www.facebook.com/aplicacionescuelas/" class="nav-link " target="_blank">
              <span>Facebook</span>
            </a>
          </li>
          <li class="nav-item">
            <a href="mailto:appescolar01@gmail.com" class="nav-link " target="_blank">
              <span>Correo: appescolar01@gmail.com</span>
            </a>
          </li>
          <li class="nav-item">
            <a href="tel:7223196667" class="nav-link " target="_blank">
              <span>Teléfono: 7223196667</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>