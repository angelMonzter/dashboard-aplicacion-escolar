<?php 

    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $db = "app_escolar";

    $conn = new mysqli($servername,$username_db,$password_db,$db) or die("connection failed");

    mysqli_set_charset($conn, 'utf8'); 

    if ($conn->connect_error) {

        echo $error -> $conn->connect_error;

    }

    // Comprobar si el método es POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Recuperar los datos enviados en la solicitud
        $data = json_decode(file_get_contents("php://input"), true);

        // Validar los datos recibidos
        if (!isset($data['accion']) || !isset($data['data'])) {
            header('HTTP/1.1 400 Bad Request');
            echo 'Error: Campos obligatorios';
            exit;
        }

        $datos_tabla = $data['data'];

        if ($data['accion'] === 'iniciar_sesion') {

            // Obtener los datos del formulario de inicio de sesión
            $username = $datos_tabla['username'];
            $password = $datos_tabla['password'];

            $sql = "SELECT * FROM usuario WHERE correo = '$username' AND contrasena = '$password'";
            $result = mysqli_query($conn, $sql);

            while ($row = mysqli_fetch_assoc($result)) {
                // Acceder a los datos de cada fila
                $correo = $row['correo'];
                $contrasena = $row['contrasena'];
            }

            // Realizar la lógica de autenticación y comprobar las credenciales
            if ($username === $correo && $password === $contrasena) {
                // Las credenciales son válidas, iniciar sesión correctamente
                session_start();
                $_SESSION['username'] = $username;

                $respuesta = array(
                    'status' => 'success',
                );
            } 
        }


        // Devolver el libro recién creado como objeto JSON
        header('Content-Type: application/json');
        echo json_encode($respuesta);
        exit;
    }

    // Si se realiza una solicitud con un método diferente a POST, devolver un error
    header('HTTP/1.1 405 Method Not Allowed');
    exit;
?>