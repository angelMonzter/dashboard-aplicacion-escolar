
function resetform(form_id) {
     $(form_id + ' select').each(function() { this.selectedIndex = 0 });
     $(form_id + ' input[type=text] , ' + form_id + '  textarea').each(function() { this.value = '' });
     $(form_id)[0].reset();
}

let datos_formulario;
function extraer_datos_form(id_form) {
    datos_formulario = $(id_form).serializeArray();
}

function insertData(datos, archivo) {
    
    $.ajax({
      url: 'http://localhost/dashboard-app-escolar/php/' + archivo, // URL de tu API
      method: 'POST', // Método HTTP a utilizar
      data: JSON.stringify(datos),
      contentType: 'application/json',
      success: function(response) {
        // Se ejecuta cuando la petición se completa exitosamente
        console.log(response);

        const { respuesta, id, modulo } = response;

        extraer_datos_form('#usuarios');
        extraer_datos_form('#niveles');
        extraer_datos_form('#grupos');
        extraer_datos_form('#grados');
        extraer_datos_form('#padres');
        extraer_datos_form('#tipo_mensajes');

        if (respuesta == 'modificacion') {

            const datos_nuevos = jQuery('[data-id="' + id + '"]').parents()[1].childNodes;

            if (modulo == 'usuarios') {
                datos_nuevos[0].innerHTML = datos_formulario[0].value;
                datos_nuevos[1].innerHTML = datos_formulario[1].value;
                datos_nuevos[2].innerHTML = datos_formulario[2].value;
                datos_nuevos[3].innerHTML = datos_formulario[4].value;
            }
            if (modulo == 'niveles') {
                datos_nuevos[0].innerHTML = datos_formulario[0].value;
            }
            if (modulo == 'grupos') {
                datos_nuevos[0].innerHTML = datos_formulario[0].value;
            }
            if (modulo == 'grados') {
                datos_nuevos[1].innerHTML = datos_formulario[1].value;
                datos_nuevos[0].innerHTML = datos_formulario[0].value;
            }
            if (modulo == 'padres') {
                datos_nuevos[1].innerHTML = datos_formulario[0].value;
                datos_nuevos[2].innerHTML = datos_formulario[1].value;
                datos_nuevos[3].innerHTML = datos_formulario[2].value;
            }
            if (modulo == 'tipo_mensajes') {
                datos_nuevos[0].innerHTML = datos_formulario[0].value;
                datos_nuevos[1].innerHTML = datos_formulario[1].value;
            }
        }
        if (respuesta == 'alta') {

            if (modulo == 'usuarios') {
                $('#tabla_usuarios').DataTable().row.add([
                    datos_formulario[0].value,
                    datos_formulario[1].value,
                    datos_formulario[2].value,
                    datos_formulario[4].value,
                    `<td>
                        <a href="#" class="btn text-white bg-secondary" data-bs-toggle="tooltip" data-bs-title="Ver detalles">
                          <i class="fa-solid fa-eye"></i>
                        </a>
                        <a href="#" class="btn text-white bg-success editar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-title="Editar">
                          <i class="fa-solid fa-pen-to-square"></i>
                        </a>
                        <a href="#" class="btn text-white bg-warning cambiar_password" data-id="${id}" data-bs-toggle="tooltip" data-bs-title="Cambiar contraseña">
                          <i class="fa-solid fa-key"></i>
                        </a>
                        <a href="#" class="btn text-white bg-danger eliminar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                          <i class="fa-solid fa-trash"></i>
                        </a>
                     </td>`,
                ]).draw(false);
                resetform('#usuarios');
            }
            if (modulo == 'niveles') {
                $('#tabla_niveles').DataTable().row.add([
                    datos_formulario[0].value,
                     `<td>
                        <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                        </a>
                     </td>`
                ]).draw(false);
                resetform('#niveles');
            }
            if (modulo == 'grupos') {
                $('#tabla_grupos').DataTable().row.add([
                    datos_formulario[0].value,
                     `<td>
                        <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                        </a>
                     </td>`
                ]).draw(false);
                resetform('#niveles');
            }
            if (modulo == 'grados') {
                $('#tabla_grados').DataTable().row.add([
                    datos_formulario[0].value,
                    datos_formulario[1].value,
                     `<td>
                        <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                        </a>
                        <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                        </a>
                     </td>`
                ]).draw(false);
                resetform('#grados');
            }
            if (modulo == 'padres') {
                $('#tabla_padres').DataTable().row.add([
                    `<td>
                      <div class="d-flex align-items-center justify-content-center">
                        <div class="form-check is-filled">
                          <input class="form-check-input" type="checkbox" id="customCheck1">
                        </div>
                      </div>
                    </td>`,
                    datos_formulario[0].value,
                    datos_formulario[1].value,
                    datos_formulario[2].value,
                    'si',
                    `<td>
                      <a href="#" class="btn text-white bg-info" data-bs-toggle="tooltip" data-bs-title="Asignar hijo">
                        <i class="fa-solid fa-user-tag"></i>
                      </a>
                      <a href="#" class="btn text-white bg-secondary" data-bs-toggle="tooltip" data-bs-title="Detalles">
                        <i class="fa-solid fa-eye"></i>
                      </a>
                      <a href="#" class="btn text-white bg-success" data-id="${id}" data-bs-toggle="tooltip" data-bs-title="Editar">
                        <i class="fa-regular fa-pen-to-square"></i>
                      </a>
                      <a href="#" class="btn text-white bg-warning" data-bs-toggle="tooltip" data-bs-title="QR">
                        <i class="fa-solid fa-qrcode"></i>
                      </a>
                      <a href="#" class="btn text-white bg-danger" data-id="${id}" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                        <i class="fa-solid fa-user-tag"></i>
                      </a>
                    </td>`,
                ]).draw(false);
                resetform('#padres');
            }
            if (modulo == 'tipo_mensajes') {
                $('#tabla_tipo_mensajes').DataTable().row.add([
                    datos_formulario[0].value,
                    datos_formulario[1].value,
                    `<td>
                      <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Preview product">
                        <i class="fa-solid fa-pen-to-square text-white"></i>
                      </a>
                      <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${id}" data-bs-toggle="tooltip" data-bs-original-title="Preview product">
                        <i class="fa-solid fa-trash text-white"></i>
                      </a>
                    </td>`,
                    
                ]).draw(false);
            }
        }
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Se ejecuta cuando hay un error en la petición
        console.log(errorThrown);
      }
    });
}

function eliminar(datos, archivo) {

    if (id, archivo) {

    }
    $.ajax({
      url: 'http://localhost/dashboard-app-escolar/php/' + archivo, // URL de tu API
      method: 'POST', // Método HTTP a utilizar
      data: JSON.stringify(datos),
      contentType: 'application/json',
      success: function(response) {
        // Se ejecuta cuando la petición se completa exitosamente
        console.log(response);
        jQuery('[data-id="' + response.id + '"]').parents()[1].remove()
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Se ejecuta cuando hay un error en la petición
        console.log(errorThrown);
      }
    });
}

function consulta(datos, archivo) {
    $.ajax({
      url: 'http://localhost/dashboard-app-escolar/php/' + archivo, // URL de tu API
      method: 'POST', // Método HTTP a utilizar
      data: JSON.stringify(datos),
      contentType: 'application/json',
      success: function(response) {
        // Se ejecuta cuando la petición se completa exitosamente
        console.log(response);
        
        const { respuesta, fila, id, modulo } = response;

        if ( respuesta == "consulta_id" ) {

            if (modulo == 'usuarios') {
                $('#nombre').val(fila[0].nombre);
                $('#apellido').val(fila[0].apellido);
                $('#correo').val(fila[0].correo);
                $('#contrasena').val(fila[0].contrasena);
            }
            if (modulo == 'niveles') {
                $('#nombre_nivel').val(fila[0].nombre);
            }
            if (modulo == 'grupos') {
                $('#nombre_grupo').val(fila[0].nombre);
            }
            if (modulo == 'grados') {
                $('#sid_nivel').val(fila[0].sid_nivel);
                $('#nombre_grado').val(fila[0].nombre);
            }
            if (modulo == 'padres') {
                $('#nombre_padre').val(fila[0].nombre);
                $('#apellido_padre').val(fila[0].apellido);
                $('#correo_padre').val(fila[0].correo);
            }
            if (modulo == 'tipo_mensajes') {
                $('#sticker_tipo_mensaje').val(fila[0].icono);
                $('#nombre_tipo_mensaje').val(fila[0].nombre);
            }
        }
        if ( respuesta == "mostrar_datos" ) {
            const numero_filas = id.length;

            if (modulo == 'usuarios') {
                //usuarios
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_usuarios').DataTable().row.add([
                        fila[i].nombre,
                        fila[i].apellido,
                        fila[i].correo,
                        fila[i].sid_rol,
                        `<td>
                            <a href="#" class="btn text-white bg-secondary" data-bs-toggle="tooltip" data-bs-title="Ver detalles">
                              <i class="fa-solid fa-eye"></i>
                            </a>
                            <a href="#" class="btn text-white bg-success editar_fila" data-id="${fila[i].id_usuario}" data-bs-toggle="tooltip" data-bs-title="Editar">
                              <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <a href="#" class="btn text-white bg-warning cambiar_password" data-id="${fila[i].id_usuario}" data-bs-toggle="tooltip" data-bs-title="Cambiar contraseña">
                              <i class="fa-solid fa-key"></i>
                            </a>
                            <a href="#" class="btn text-white bg-danger eliminar_fila" data-id="${fila[i].id_usuario}" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                              <i class="fa-solid fa-trash"></i>
                            </a>
                         </td>`,
                    ]).draw(false);
                }
            }
            if (modulo == 'niveles') {
                //niveles
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_niveles').DataTable().row.add([
                        fila[i].nombre,
                        `<td>
                          <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${fila[i].id_nivel}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${fila[i].id_nivel}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>`,
                         
                    ]).draw(false);
                }
            }
            if (modulo == 'grupos') {
                //grupos
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_grupos').DataTable().row.add([
                        fila[i].nombre,
                        `<td>
                          <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${fila[i].id_grupo}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${fila[i].id_grupo}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>`,
                         
                    ]).draw(false);
                }
            }
            if (modulo == 'grados') {
                //grados
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_grados').DataTable().row.add([
                        fila[i].sid_nivel,
                        fila[i].nombre,
                        `<td>
                          <a href="javascript:;" class="bg-dark shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Detalles">
                            <i class="fa-solid fa-magnifying-glass text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${fila[i].id_grado}" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${fila[i].id_grado}" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>`,
                         
                    ]).draw(false);
                }
            }
            if (modulo == 'padres') {
                //padres
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_padres').DataTable().row.add([
                        `<td>
                          <div class="d-flex align-items-center justify-content-center">
                            <div class="form-check is-filled">
                              <input class="form-check-input" type="checkbox" id="customCheck1">
                            </div>
                          </div>
                        </td>`,
                        fila[i].nombre,
                        fila[i].apellido,
                        fila[i].correo,
                        'si',
                        `<td>
                          <a href="#" class="btn text-white bg-info" data-bs-toggle="tooltip" data-bs-title="Asignar hijo">
                            <i class="fa-solid fa-user-tag"></i>
                          </a>
                          <a href="#" class="btn text-white bg-secondary" data-bs-toggle="tooltip" data-bs-title="Detalles">
                            <i class="fa-solid fa-eye"></i>
                          </a>
                          <a href="#" class="btn text-white bg-success editar_fila" data-id="${fila[i].id_padre}" data-bs-toggle="tooltip" data-bs-title="Editar">
                            <i class="fa-regular fa-pen-to-square"></i>
                          </a>
                          <a href="#" class="btn text-white bg-warning" data-bs-toggle="tooltip" data-bs-title="QR">
                            <i class="fa-solid fa-qrcode"></i>
                          </a>
                          <a href="#" class="btn text-white bg-danger eliminar_fila" data-id="${fila[i].id_padre}" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>`,
                    ]).draw(false);
                }
            }
            if (modulo == 'tipo_mensajes') {
                //tipo de mensajes
                //console.log(fila);
                for (var i = 0; i < numero_filas; i++) {
                    $('#tabla_tipo_mensajes').DataTable().row.add([
                        fila[i].icono,
                        fila[i].nombre,
                        `<td>
                          <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button editar_fila" data-id="${fila[i].id_tipo_mensaje}" data-bs-toggle="tooltip" data-bs-original-title="Preview product">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button eliminar_fila" data-id="${fila[i].id_tipo_mensaje}" data-bs-toggle="tooltip" data-bs-original-title="Preview product">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>`,
                        
                    ]).draw(false);
                }
            }
        }
      },
      error: function(jqXHR, textStatus, errorThrown) {
        // Se ejecuta cuando hay un error en la petición
        console.log(errorThrown);
      }
    });
}

$('#guardar').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#usuarios').serializeArray();

    const datos_tabla = {
        nombre: datos_formulario[0].value,
        apellido: datos_formulario[1].value,
        correo: datos_formulario[2].value,
        contrasena: datos_formulario[3].value,
        sid_rol: datos_formulario[4].value,
        id: datos_formulario[5].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }

    insertData(datos, 'usuario.php');
});

$('#guardar_nivel').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#niveles').serializeArray();

    const datos_tabla = {
        nombre: datos_formulario[0].value,
        sid_institucion: 2,
        id: datos_formulario[1].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }

    insertData(datos, 'nivel.php');
});

$('#guardar_grupo').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#grupos').serializeArray();

    const datos_tabla = {
        nombre_grupo: datos_formulario[0].value,
        sid_grado: 2,
        id: datos_formulario[1].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }
    
    insertData(datos, 'grupo.php');
});

$('#guardar_grado').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#grados').serializeArray();

    const datos_tabla = {
        sid_nivel: datos_formulario[0].value,
        nombre_grado: datos_formulario[1].value,
        id: datos_formulario[2].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }
    
    insertData(datos, 'grado.php');
});

$('#guardar_padres').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#padres').serializeArray();

    const datos_tabla = {
        nombre_padre: datos_formulario[0].value,
        apellido_padre: datos_formulario[1].value,
        correo_padre: datos_formulario[2].value,
        id: datos_formulario[3].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }

    insertData(datos, 'padre.php');
});
$('#guardar_tipo_mensajes').on('click', function (e) {
    e.preventDefault();

    const datos_formulario = $('#tipo_mensajes').serializeArray();

    const datos_tabla = {
        sticker_tipo_mensaje: datos_formulario[0].value,
        nombre_tipo_mensaje: datos_formulario[1].value,
        id: datos_formulario[2].value
    };

    const datos = {
        accion: 'insertar',
        data: datos_tabla,
    }

    insertData(datos, 'tipo_mensaje.php');
});

$('#tabla_usuarios').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'usuario.php');
});

$('#tabla_niveles').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'nivel.php');
});

$('#tabla_grupos').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'grupo.php');
});
$('#tabla_grados').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'grado.php');
});
$('#tabla_padres').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'padre.php');
});

/////////fincion eliminar datos en cortooo!!  
/////////se puede agregar a la funcion "eliminar(datos, archivo);" y recortar mas 
function eliminar_datos(id_eliminar, archivo) {
    const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, archivo);
}
$('#tabla_tipo_mensajes').on('click', '.eliminar_fila', function (e) {
    e.preventDefault();

    const id_eliminar = $(this).attr('data-id');

    /*const datos_tabla = {
        id: id_eliminar
    };

    const datos = {
        accion: 'eliminar',
        data: datos_tabla,
    }
    
    eliminar(datos, 'tipo_mensaje.php');*/
    eliminar_datos(id_eliminar, 'tipo_mensaje.php');
});

$('#tabla_usuarios').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'usuario.php');
});

$('#tabla_niveles').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'nivel.php');
});

$('#tabla_grupos').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'grupo.php');
});

$('#tabla_grados').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'grado.php');
});

$('#tabla_padres').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'padre.php');
});

/////////fincion cargar datos en cortooo!! 
function cargar_datos_modificar(id_modificar, archivo) {

    $('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, archivo);
}

$('#tabla_tipo_mensajes').on('click', '.editar_fila', function (e) {
    e.preventDefault();

    const id_modificar = $(this).attr('data-id');

    /*$('.id_modificar').val(id_modificar);

    const datos_tabla = {
        id: id_modificar
    };

    const datos = {
        accion: 'consulta',
        data: datos_tabla,
    }
    
    consulta(datos, 'tipo_mensaje.php');*/
    cargar_datos_modificar(id_modificar, 'tipo_mensaje.php');
});




function consultarDatosExistentes(nombre_tabla, informacion) {
    const tabla = $(nombre_tabla);
    const archivo = $(nombre_tabla).attr('data-name');
    
    if (tabla.length > 0) {
        consulta(informacion, archivo);
    }else{

    }
}

$( document ).ready(function() {

    const informacion_tabla = {
        id: ''
    };

    const informacion = {
        accion: 'consulta',
        data: informacion_tabla,
    }

    consultarDatosExistentes('#tabla_usuarios', informacion);
    consultarDatosExistentes('#tabla_niveles', informacion);
    consultarDatosExistentes('#tabla_grupos', informacion);
    consultarDatosExistentes('#tabla_grados', informacion);
    consultarDatosExistentes('#tabla_padres', informacion);
    consultarDatosExistentes('#tabla_tipo_mensajes', informacion);
});