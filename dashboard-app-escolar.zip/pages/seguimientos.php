<?php
$datatable = true;
include_once('../templates/header.php')
?>

<body class="g-sidenav-show  bg-gray-200">
  <!-- ASIDE / MENU IZQUIERDO  -->
  <?php include_once('../templates/aside.php') ?>
  <!-- ASIDE / MENU IZQUIERDO  -->

  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <?php include_once('../templates/navbar.php') ?>
    <!-- Navbar -->

    <div class="container-fluid py-4">
      <!-- Content -->
      <div class="row">

        <?php
        // - Submenu
        ?>
        <div class="container-fluid mt-4">
          <div class="align-items-center">
            <div class="col-lg-4 col-sm-7">
              <div class="nav-wrapper position-relative">

                <ul class="nav nav-pills nav-fill p-1" id="myTab" role="tablist">

                  <li class="nav-item" role="presentation">
                    <a class="nav-link mb-0 px-0 py-1 active " data-bs-toggle="tab" href="#option1" role="tab" aria-selected="false">
                      Atributos
                    </a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link mb-0 px-0 py-1 " data-bs-toggle="tab" href="#option2" role="tab" aria-selected="false">
                      Cargar Seguimientos
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link mb-0 px-0 py-1 " data-bs-toggle="tab" href="#option3" role="tab" aria-selected="false">
                      Seguimientos Academicos
                    </a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link mb-0 px-0 py-1" data-bs-toggle="tab" href="#option4" role="tab" aria-selected="false">
                      Registro
                    </a>
                  </li>

                  <div class="moving-tab position-absolute nav-link" style="padding: 0px; transition: all 0.5s ease 0s; transform: translate3d(0px, 0px, 0px); width: 137px;">
                    <a class="nav-link mb-0 px-0 py-1 active" data-bs-toggle="tab" role="tab" aria-selected="true">➡</a>
                  </div>
                </ul>

              </div>
            </div>
          </div>
        </div>


        <?php
        // - Opciones
        ?>
        <div class="col-12 mt-4 tab-content" role="tablist">

          <?php
          //# Opcion 1
          ?>
          <div class="my-4 tab-pane fade show active" role="tabpanel" id="option1">

            <!-- Formulario -->
            <div class="col-xl-12 mt-3">
              <div class="card">
                <div class="card-body">

                  <h5 class="font-weight-bolder">Agregar Atributo</h5>
                  <form id="atributo">
                    <div class="row align-items-center">
                      <div class="col-lg-4">
                        <div class="input-group input-group-dynamic mt-3">
                          <label class="input-group">Elije un sticker</label>
                          <select name="icono" id="icono" class="form-control" aria-label="Default select example">
                            <option selected>Selecciona una opción</option>
                            <option value="https://api.aplicacionescolar.net/general/general-file-1611278016288.svg">
                              <img src="https://api.aplicacionescolar.net/general/general-file-1611278016288.svg"
                                class="icono_tabla" alt="">
                              Rol Imagen
                            </option>
                          </select>
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="input-group input-group-dynamic mt-3">
                          <label class="input-group">Nombre</label>
                          <input type="text" class="form-control" name="nombre_atributo" id="nombre_atributo"
                            aria-describedby="emailHelp" onfocus="focused(this)" onfocusout="defocused(this)">
                        </div>
                      </div>
                      <div class="col-lg-4">
                        <div class="input-group input-group-dynamic mt-3">
                          <label class="input-group">Valor</label>
                          <input type="number" class="form-control" name="valor_atributo" id="valor_atributo"
                            aria-describedby="emailHelp" onfocus="focused(this)" onfocusout="defocused(this)">
                        </div>
                      </div>
                      <div class="mt-3" align="right">
                        <a href="#" class="btn bg-gradient-success mb-0 me-2" id="add_atributo">Agregar</a>
                        <input type="hidden" class="id_modificar" name="id_modificar" value="">
                      </div>
                    </div>
                  </form>

                </div>
              </div>
            </div>

            <!-- datatable -->
            <div class="col-12 mt-4">
              <div class="card">
                <div class="card-header">
                  <table id="tabla_atributo" data-name="atributo.php" class="table table-striped" style="width:100%">
                    <thead>
                      <tr>
                        <th>Sticker</th>
                        <th>Nombre</th>
                        <th>Valor</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <img src="https://api.aplicacionescolar.net/general/general-file-1611278016288.svg" class="icono_tabla" alt="">
                        </td>
                        <td>Cumplió</td>
                        <td>1</td>
                        <td>
                          <a href="javascript:;" class="bg-gradient-success shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Editar">
                            <i class="fa-solid fa-pen-to-square text-white"></i>
                          </a>
                          <a href="javascript:;" class="bg-gradient-danger shadow border-radius-md p-2 table_button" data-bs-toggle="tooltip" data-bs-original-title="Eliminar">
                            <i class="fa-solid fa-trash text-white"></i>
                          </a>
                        </td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>Sticker</th>
                        <th>Nombre</th>
                        <th>Valor</th>
                        <th>Acciones</th>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>

          </div>

          <?php
          //# Opcion 2
          ?>
          <div class="my-4 tab-pane fade" role="tabpanel" id="option2">
            <!-- Formulario -->
            <div class="col-xl-12 mt-3 mb-6">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-wrap justify-content-between">
                    <div>
                      <h5 class="font-weight-bolder">Como subir un archivo</h5>
                      <p class="text-sm">Los pasos para subir un archivo son los siguientes:</p>
                    </div>
                    <div>
                      <button type="button" class="btn bg-secondary text-white" data-bs-toggle="modal" data-bs-target="#seguimientoModal">
                        <i class="fa-solid fa-circle-info mx-1"></i>
                        Requerimientos de archivo
                      </button>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 col-12">
                      <div class="card card-plain text-center">
                        <div class="card-body">
                          <button class="btn bg-info shadow text-center text-white">
                            <i class="fa-solid fa-arrow-up-from-bracket"></i>
                          </button>
                          <p class="text-sm font-weight-normal mb-2"> <b>Paso 1:</b> Subir Archivo</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-12">
                      <div class="card card-plain text-center">
                        <div class="card-body">
                          <button class="btn bg-warning shadow text-center text-white">
                            <i class="fa-regular fa-square-check"></i>
                          </button>
                          <p class="text-sm font-weight-normal mb-2"> <b>Paso 2:</b> Validar Archivo</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 col-12">
                      <div class="card card-plain text-center">
                        <div class="card-body">
                          <button class="btn bg-success shadow text-center text-white">
                            <i class="fa-regular fa-floppy-disk"></i>
                          </button>
                          <p class="text-sm font-weight-normal mb-2"> <b>Paso 3:</b> Guardar en la Base de Datos</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- datatable -->
            <div class="col-12 mt-4">
              <div class="card">
                <div class="card-header">
                  <div class="col-12 mt-2 mb-4">
                    <div class="mt-3 d-flex justify-content-end">
                      <button type="button" class="btn btn-info">
                        <i class="fa-solid fa-arrow-up-from-bracket"></i>
                        Subir Archivo
                      </button>
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table id="example2" class="table table-striped" style="width:100%">
                      <thead>
                        <tr>
                          <th class="text-center">Archivos</th>
                          <th class="text-center">Fecha de Subida</th>
                          <th class="text-center">Estado</th>
                          <th class="text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody class="text-center">
                        <tr class="text-center">
                          <td>general-file-1613669186365.xlsx</td>
                          <td> 2022-08-16 10:54:57</td>
                          <td>
                            <span class="badge badge-sm bg-gradient-success">Guardado</span>
                          </td>
                          <td>
                            <a href="#" class="btn text-white bg-warning" data-bs-toggle="tooltip" data-bs-title="Validar">
                              <i class="fa-regular fa-square-check"></i>
                            </a>
                            <a href="#" class="btn text-white bg-success" data-bs-toggle="tooltip" data-bs-title="Guardar">
                              <i class="fa-regular fa-floppy-disk"></i>
                            </a>
                            <a href="#" class="btn text-white bg-danger" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                              <i class="fa-solid fa-trash"></i>
                            </a>
                          </td>
                        </tr>
                        <tr class="text-center">
                          <td>general-file-1613669186365.xlsx</td>
                          <td> 2022-08-16 10:54:57</td>
                          <td>
                            <span class="badge badge-sm bg-gradient-success">Guardado</span>
                          </td>
                          <td>
                            <a href="#" class="btn text-white bg-warning" data-bs-toggle="tooltip" data-bs-title="Validar">
                              <i class="fa-regular fa-square-check"></i>
                            </a>
                            <a href="#" class="btn text-white bg-success" data-bs-toggle="tooltip" data-bs-title="Guardar">
                              <i class="fa-regular fa-floppy-disk"></i>
                            </a>
                            <a href="#" class="btn text-white bg-danger" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                              <i class="fa-solid fa-trash"></i>
                            </a>
                          </td>
                        </tr>

                      </tbody>
                      <tfoot>
                        <tr>
                          <th class="text-center">Archivos</th>
                          <th class="text-center">Fecha de Subida</th>
                          <th class="text-center">Estado</th>
                          <th class="text-center">Acciones</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <?php
          // # Opcion 3
          ?>
          <div class="my-4 tab-pane fade" role="tabpanel" id="option3">
            <!-- Datatable -->
            <div class="col-12 mt-4">
              <div class="card">
                <div class="card-header">
                  <div class="col-12 mt-2 mb-4">
                    <div class="mt-3" align="right">
                      <div class="px-5">
                        <button type="button" class="btn btn-outline-info">Eliminar Seleccionados</button>
                        <button type="button" class="btn btn-outline-success">Exportar Excel</button>
                      </div>
                    </div>
                  </div>
                  <div class="table-responsive">
                    <table id="example3" class="table table-striped" style="width:100%">
                      <thead>
                        <tr>
                          <th class="text-center">Seleccionar</th>
                          <th class="text-center">Usuario</th>
                          <th class="text-center">Padre</th>
                          <th class="text-center">Estudiante</th>
                          <th class="text-center">Enviado</th>
                          <th class="text-center">Leido</th>
                          <th class="text-center">Visto</th>
                          <th class="text-center">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr class="text-center">
                          <td>
                            <div class="d-flex align-items-center">
                              <div class="form-check is-filled">
                                <input class="form-check-input" type="checkbox" id="customCheck1">
                              </div>
                            </div>
                          </td>
                          <td>APLICACIÓN ESCOLAR PRO </td>
                          <td>VANESSA ZEPEDA MEBARAK </td>
                          <td>KEVIN ZEPEDA </td>
                          <td>2023-03-31 00:13:06 </td>
                          <td>
                            <span class="badge badge-sm bg-gradient-success">Guardado</span>
                          </td>
                          <td>2023-03-31 00:13:06 </td>
                          <td>
                            <a href="#" class="btn text-white bg-secondary" data-bs-toggle="tooltip" data-bs-title="Detalles">
                              <i class="fa-solid fa-eye"></i>
                            </a>
                            <a href="#" class="btn text-white bg-danger" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                              <i class="fa-solid fa-trash-can"></i>
                            </a>
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <th class="text-center">Seleccionar</th>
                          <th class="text-center">Usuario</th>
                          <th class="text-center">Padre</th>
                          <th class="text-center">Estudiante</th>
                          <th class="text-center">Enviado</th>
                          <th class="text-center">Leido</th>
                          <th class="text-center">Visto</th>
                          <th class="text-center">Acciones</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- Detalles -->
            <div class="col-12 col-md-9 mx-auto position-relative mt-6">
              <div class="card">
                <div class="card-header pb-0 px-3">
                  <h6 class="mb-0 fs-4">Datos del seguimiento</h6>
                </div>
                <div class="card-body pt-4 p-3">

                  <div class="row">
                    <div class="d-flex align-items-stretch">

                      <ul class="list-group col-12 p-2">
                        <li class="list-group-item border-0 d-flex p-4 mb-2 bg-gray-100 border-radius-lg">
                          <div class="d-flex flex-column">
                            <span class="mb-2 text-sm">Usuario: <span class="text-dark ms-sm-2 font-weight-bold">APLICACIÓN ESCOLAR PRO</span></span>
                            <span class="mb-2 text-sm">Padre: <span class="text-dark font-weight-bold ms-sm-2">VANESSA ZEPEDA MEBARAK</span></span>
                            <span class="mb-2 text-sm">Estudiante: <span class="text-dark font-weight-bold ms-sm-2">KEVIN ZEPEDA</span></span>
                            <span class="mb-2 text-sm">Enviado: <span class="text-dark font-weight-bold ms-sm-2">2023-03-31 00:13:06</span></span>
                            <span class="mb-2 text-sm">Leído: <span class="badge badge-sm bg-gradient-success">Sí</span></span>
                            <span class="mb-2 text-sm">Visto: <span class="text-dark font-weight-bold ms-sm-2">2023-04-27 11:15:26</span></span>
                          </div>
                        </li>
                      </ul>

                    </div>
                  </div>

                  <div class="row">
                    <h6 class="mb-0 fs-4">Detalles del Seguimiento</h6>
                    <div class="form-group d-flex">
                      <div class="col-6 px-2 my-4">
                        <div class="input-group input-group-dynamic mt-3">
                          <label class="input-group">Tipo de Mensaje</label>
                          <select name="" id="" class="form-control" aria-label="Default select example">
                            <option selected>Selecciona una opción</option>
                            <option value="opt1">opción 1 </option>
                            <option value="opt2">opción 2 </option>
                          </select>
                        </div>
                      </div>
                      <div class="col-6 px-2 my-4">
                        <div class="input-group input-group-dynamic mt-3">
                          <label class="input-group">Nombre</label>
                          <input type="text" class="form-control" aria-describedby="emailHelp" onfocus="focused(this)" onfocusout="defocused(this)">
                        </div>
                      </div>
                    </div>
                    <div class="col-12 text-end mb-4">
                      <button type="button" name="button" class="btn btn-success m-0">Guardar</button>
                    </div>


                    <div class="input-group input-group-dynamic mb-4">
                      <label class="input-group">Observacion</label>
                      <input type="text" class="form-control" aria-label="Recipient's username" aria-describedby="button-addon2">
                      <button class="btn btn-success mb-0" type="button" id="button-addon2">
                        <i class="fa-regular fa-pen-to-square"></i>
                      </button>
                    </div>

                  </div>

                  <!-- Table -->
                  <div class="row">
                    <div class="table-responsive">
                      <table id="example6" class="table table-striped" style="width:100%">
                        <thead>
                          <tr>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Valor</th>
                            <th class="text-center">Acciones</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr class="text-center">
                            <td>Aseo</td>
                            <td>Presentación</td>
                            <td>
                              <a href="#" class="btn text-white bg-success" data-bs-toggle="tooltip" data-bs-title="Guardar">
                                <i class="fa-regular fa-floppy-disk"></i>
                              </a>
                              <a href="#" class="btn text-white bg-danger" data-bs-toggle="tooltip" data-bs-title="Eliminar">
                                <i class="fa-solid fa-trash"></i>
                              </a>
                            </td>
                          </tr>
                        </tbody>
                        <tfoot>
                          <tr>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Valor</th>
                            <th class="text-center">Acciones</th>
                          </tr>
                        </tfoot>
                      </table>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                      <button type="button" name="button" class="btn btn-danger m-0">Cancelar</button>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </div>

          <?php
          // # Opcion 4
          ?>
          <div class="my-4 tab-pane fade" role="tabpanel" id="option4">
            <!-- Datatable -->
            <div class="col-12 mt-4">
              <div class="card">
                <div class="card-header">
                  <div class="table-responsive">
                    <table id="example4" class="table table-striped" style="width:100%">
                      <thead>
                        <tr>
                          <th class="text-center">Usuario</th>
                          <th class="text-center">Padre</th>
                          <th class="text-center">Estudiante</th>
                          <th class="text-center">Enviado</th>
                          <th class="text-center">Responsable</th>
                          <th class="text-center">Fecha de Eliminación</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr class="text-center">
                          <td>APLICACIÓN ESCOLAR PRO </td>
                          <td>VANESSA ZEPEDA MEBARAK </td>
                          <td>KEVIN ZEPEDA </td>
                          <td>2023-03-31 00:13:06 </td>
                          <td>APLICACIÓN ESCOLAR PRO </td>
                          <td>2023-03-31 00:13:06 </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <th class="text-center">Usuario</th>
                          <th class="text-center">Padre</th>
                          <th class="text-center">Estudiante</th>
                          <th class="text-center">Enviado</th>
                          <th class="text-center">Responsable</th>
                          <th class="text-center">Fecha de Eliminación</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

        <?php
        //- Modales
        ?>
        <!-- Cargar Archivo -->
        <div class="modal fade" id="seguimientoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">¿Cómo cargar el archivo?</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <p>El Archivo debe tener las siguientes cabeceras:</p>
                <ul>
                  <li>Matricula</li>
                  <li>Observaciones</li>
                  <li>NombreEvaluación1</li>
                  <li>NombreEvaluacion2</li>
                  <li>...</li>
                  <li>NombreEvaluacionN</li>
                </ul>
                <p>Puede descargar el siguiente archivo base para cargar su información.</p>
                <a href="https://api.aplicacionescolar.net/general/general-file-1613669186365.xlsx" target="_blank" rel="noopener noreferrer" class="btn btn-success">
                  <i class="fa-solid fa-file-excel"></i>
                  Archivo Base
                </a>
                <p>A continuación una foto de como debería verse el archivo al final:</p>
                <img src="https://aplicacionescolar.net/static/media/seguimientos.ac90d18c.png" alt="calificaciones_image" style="width: 95%; padding: 2%;">
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">cerrar</button>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!-- Content -->

      <!-- Footer -->
      <?php include_once('../templates/footer.php') ?>
      <!-- Footer -->

    </div>

  </main>

  <!-- Scripts -->
  <?php
  include_once('../templates/script.php');
  ?>
  <!-- Scripts -->
</body>

</html>