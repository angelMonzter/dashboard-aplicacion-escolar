<?php 
	require("conexion.php");
	class Mensaje extends DBA{
		public function alta($id_mensaje,$sid_tipo,$sid_alumno,$nivel,$grado,$grupo,$sid_extracurricular,$asunto,$mensaje,$archivo_adjunto,$url,$respuesta_rapida,$mensaje_programado,$fecha_envio,$hora_envio,$repetir,$periodo,$fecha_fin) {
			$this->sentencia = "INSERT INTO mensaje VALUES ($id_mensaje,'$sid_tipo','$sid_alumno','$nivel','$grado','$grupo','$sid_extracurricular','$asunto','$mensaje','$archivo_adjunto','$url','$respuesta_rapida','$mensaje_programado','$fecha_envio','$hora_envio','$repetir','$periodo','$fecha_fin');";
			return $this->ejecutar_sentencia();
		}
		public function consulta() {
			$this->sentencia = "SELECT * FROM mensaje;";
			return $this->obtener_sentencia();
		}
		public function consultar_id($id){
            $this->sentencia = "SELECT * FROM mensaje WHERE id_mensaje = $id;";
            return $this->obtener_sentencia();
        }
		public function modificar($sid_tipo,$sid_alumno,$nivel,$grado,$grupo,$sid_extracurricular,$asunto,$mensaje,$archivo_adjunto,$url,$respuesta_rapida,$mensaje_programado,$fecha_envio,$hora_envio,$repetir,$periodo,$fecha_fin,$id){
			$this->sentencia="UPDATE mensaje SET sid_tipo = '$sid_tipo', sid_alumno = '$sid_alumno', nivel = '$nivel', grado = '$grado', grupo = '$grupo', sid_extracurricular = '$sid_extracurricular', asunto = '$asunto', mensaje = '$mensaje', archivo_adjunto = '$archivo_adjunto', url = '$url', respuesta_rapida = '$respuesta_rapida', mensaje_programado = '$mensaje_programado', fecha_envio = '$fecha_envio', hora_envio = '$hora_envio', repetir = '$repetir', periodo = '$periodo', fecha_fin = '$fecha_fin' WHERE id_mensaje = $id;";
			return $this->ejecutar_sentencia();
		}
		public function eliminar($id){
            $this->sentencia="DELETE FROM mensaje WHERE id_mensaje = $id";
			return $this->ejecutar_sentencia();
		}
		public function id($value){
			return $this->generator($value);
		}
	}

	// Comprobar si el método es POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Recuperar los datos enviados en la solicitud
        $data = json_decode(file_get_contents("php://input"), true);

        // Validar los datos recibidos
        if ( !isset($data['accion']) || !isset($data['data']) ) {
            header('HTTP/1.1 400 Bad Request');
            echo 'Error: Campos obligatorios';
            exit;
        }
        
        $datos_tabla = $data['data'];

        $obj = new Mensaje();
        
        if ($data['accion'] === 'insertar') {

            $id = $datos_tabla['id'];

            $sid_tipo = $datos_tabla['sid_tipo'];
            $sid_estudiante = $datos_tabla['sid_estudiante'];
            $asunto = $datos_tabla['asunto_mensaje'];

            //falta mandar el mensaje, los adjuntos y sigueintes campos
            //$mensaje = $datos_tabla['textarea_mensaje'];
            $mensaje = 'mensaje';
            $archivo_adjunto = 'archivo_adjunto';
            $url = 'url';
            $respuesta_rapida = 'si';
            $mensaje_programado = 'si';

            $fecha_envio = $datos_tabla['fecha_envio_mensaje'];
            $hora_envio_mensaje = $datos_tabla['hora_envio_mensaje'];
            $minutos_envio_mensaje = $datos_tabla['minutos_envio_mensaje'];
            $hora_envio = $hora_envio_mensaje . ':' . $minutos_envio_mensaje;
            $repetir = $datos_tabla['repetir_mensaje'];
            $minutos_envio = $datos_tabla['minutos_envio_mensaje'];
            $periodo = $datos_tabla['periodo_mensaje'];
            $fecha_fin = $datos_tabla['fecha_fin_mensaje'];

            //revisar en base de datos por que si jalamos el alumno se supone que ya traemos el nivel grado y grupo
            $nivel = 'nivel';
            $grado = 'grado';
            $grupo = 'grupo';
            $sid_extracurricular = 1;

            if (empty($id)) {

                $id = $obj->id(5);

                $resultado = $obj->alta($id,$sid_tipo,$sid_estudiante,$nivel,$grado,$grupo,$sid_extracurricular,$asunto,$mensaje,$archivo_adjunto,$url,$respuesta_rapida,$mensaje_programado,$fecha_envio,$hora_envio,$repetir,$periodo,$fecha_fin);

                $respuesta = array(
                    'respuesta' => 'alta',
                    'resultado' => $resultado,
                    'modulo' => 'mensajes',
                );
            }else{

                $resultado = $obj->modificar($nombre, $id);

                $respuesta = array(
                    'respuesta' => 'modificacion',
                    'id' => $id,
                    'resultado' => $resultado,
                    'modulo' => 'mensajes',
                );
            }
        }
        
        require("funciones.php");

        $id = $datos_tabla['id']; 
        
        if ($data['accion'] === 'eliminar') {

            $respuesta = eliminarFila($id, $obj);
        }

        if ($data['accion'] === 'consulta') {

            $respuesta = consultarFilas($id, $obj, 'id_mensaje', 'mensajes');
        }

        // Devolver el libro recién creado como objeto JSON
        header('Content-Type: application/json');
        echo json_encode($respuesta);
        exit;
    }

    // Si se realiza una solicitud con un método diferente a POST, devolver un error
    header('HTTP/1.1 405 Method Not Allowed');
    exit;
?>
				