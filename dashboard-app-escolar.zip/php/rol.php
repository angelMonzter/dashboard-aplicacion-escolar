
				<?php 
				require("mysql/conexion.php");
				class Rol extends DBA{
					public function alta($id_rol,$sid_institucion,$nombre,$privilegios,$fecha_registro) {
						$this->sentencia = "INSERT INTO rol VALUES ($id_rol,'$sid_institucion','$nombre','$privilegios','$fecha_registro');";
						$this->ejecutar_sentencia();
					}
					public function consulta() {
						$this->sentencia = "SELECT * FROM rol;";
						return $this->obtener_sentencia();
					}
					public function modificar($id_rol,$sid_institucion,$nombre,$privilegios,$fecha_registro){
						$this->sentencia="UPDATE $id_rol,'$sid_institucion','$nombre','$privilegios','$fecha_registro' FROM rol;";
						$this->ejecutar_sentencia();
					}
					public function eliminar(){
						$this->sentencia="DELETE $id_rol,'$sid_institucion','$nombre','$privilegios','$fecha_registro' FROM rol;";
						$this->ejecutar_sentencia();
					}
				}
				?>
				