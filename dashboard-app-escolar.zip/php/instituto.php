
				<?php 
				require("mysql/conexion.php");
				class Instituto extends DBA{
					public function alta($id_instituto,$logo,$correo,$banco,$cuenta_banco,$descripcion,$fecha_inicio_licencia,$fecha_limite,$politicas,$nombre_beneficiario,$asistencia,$pago) {
						$this->sentencia = "INSERT INTO instituto VALUES ($id_instituto,'$logo','$correo','$banco','$cuenta_banco','$descripcion','$fecha_inicio_licencia','$fecha_limite','$politicas','$nombre_beneficiario','$asistencia','$pago');";
						$this->ejecutar_sentencia();
					}
					public function consulta() {
						$this->sentencia = "SELECT * FROM instituto;";
						return $this->obtener_sentencia();
					}
					public function modificar($id_instituto,$logo,$correo,$banco,$cuenta_banco,$descripcion,$fecha_inicio_licencia,$fecha_limite,$politicas,$nombre_beneficiario,$asistencia,$pago){
						$this->sentencia="UPDATE $id_instituto,'$logo','$correo','$banco','$cuenta_banco','$descripcion','$fecha_inicio_licencia','$fecha_limite','$politicas','$nombre_beneficiario','$asistencia','$pago' FROM instituto;";
						$this->ejecutar_sentencia();
					}
					public function eliminar(){
						$this->sentencia="DELETE $id_instituto,'$logo','$correo','$banco','$cuenta_banco','$descripcion','$fecha_inicio_licencia','$fecha_limite','$politicas','$nombre_beneficiario','$asistencia','$pago' FROM instituto;";
						$this->ejecutar_sentencia();
					}
				}
				?>
				