
				<?php 
				require("mysql/conexion.php");
				class Seguimiento extends DBA{
					public function alta($id_seguimiento,$sid_alumno,$nombre_atributo,$nombre_evaluacion,$fecha_registro) {
						$this->sentencia = "INSERT INTO seguimiento VALUES ($id_seguimiento,'$sid_alumno','$nombre_atributo','$nombre_evaluacion','$fecha_registro');";
						$this->ejecutar_sentencia();
					}
					public function consulta() {
						$this->sentencia = "SELECT * FROM seguimiento;";
						return $this->obtener_sentencia();
					}
					public function modificar($id_seguimiento,$sid_alumno,$nombre_atributo,$nombre_evaluacion,$fecha_registro){
						$this->sentencia="UPDATE $id_seguimiento,'$sid_alumno','$nombre_atributo','$nombre_evaluacion','$fecha_registro' FROM seguimiento;";
						$this->ejecutar_sentencia();
					}
					public function eliminar(){
						$this->sentencia="DELETE $id_seguimiento,'$sid_alumno','$nombre_atributo','$nombre_evaluacion','$fecha_registro' FROM seguimiento;";
						$this->ejecutar_sentencia();
					}
				}
				?>
				