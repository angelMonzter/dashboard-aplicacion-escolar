
				<?php 
				require("mysql/conexion.php");
				class Evento extends DBA{
					public function alta($id_evento,$nombre,$fecha,$todos,$nivel,$grado,$grupo,$sid_instituto) {
						$this->sentencia = "INSERT INTO evento VALUES ($id_evento,'$nombre','$fecha','$todos','$nivel','$grado','$grupo','$sid_instituto');";
						$this->ejecutar_sentencia();
					}
					public function consulta() {
						$this->sentencia = "SELECT * FROM evento;";
						return $this->obtener_sentencia();
					}
					public function modificar($id_evento,$nombre,$fecha,$todos,$nivel,$grado,$grupo,$sid_instituto){
						$this->sentencia="UPDATE $id_evento,'$nombre','$fecha','$todos','$nivel','$grado','$grupo','$sid_instituto' FROM evento;";
						$this->ejecutar_sentencia();
					}
					public function eliminar(){
						$this->sentencia="DELETE $id_evento,'$nombre','$fecha','$todos','$nivel','$grado','$grupo','$sid_instituto' FROM evento;";
						$this->ejecutar_sentencia();
					}
				}
				?>
				